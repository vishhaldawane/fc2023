export function sayHi(user) {
  alert(`Hello, ${user}!`);
}