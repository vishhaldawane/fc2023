import {user} from './user.js';

document.body.innerHTML = user; // John